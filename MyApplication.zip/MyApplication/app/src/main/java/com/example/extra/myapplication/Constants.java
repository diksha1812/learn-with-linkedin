package com.example.extra.myapplication;

import android.support.v7.widget.LinearSmoothScroller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Constants {
    public static final String DEVELOPER_KEY = "AIzaSyBYdzQ_dBZEJ15EWCASNFfo4QGxLDsv0yo";
    public static final String TAG = "LOG MESSAGE";
    public static final List<String> keywords = new ArrayList<String>(Arrays.asList("Skills for Managers", "Public Speaking",
            "Positive Psychology", "Career Development", "Presentation Skills", "Operating Systems", "Computer Networks",
            "Data Structures", "Algorithms", "Web Development", "Android", "Augmented Reality", "Software Architecture", "C++", "C", "Java",
            "Machine Learning", "Artificial Intelligence", "Data Mining", "Data Analytics", "Deep Learning", "Big Data", "Python", "R Language",
            "Statistics", "Foundation Business", "Business Analytics", "Management", "Financial Modelling", "Accounting", "Economics",
            "Robotics", "Metallurgy", "Civil", "Mechanics", "Creative Writing", "Photography", "Music", "Journalist", "Fashion Designing",
            "Chinese", "Spanish", "German", "Business English Communication Skills"
));
}

